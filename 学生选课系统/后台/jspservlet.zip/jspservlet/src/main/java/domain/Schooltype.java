package domain;

import java.io.Serializable;

public class Schooltype implements Serializable {
    private String schooltype;

    public String getSchooltype() {
        return schooltype;
    }

    public void setSchooltype(String schooltype) {
        this.schooltype = schooltype;
    }
}
